
# Online Shooter Game (Top-Down)

## 💥 How to Run:

1. `npm install`
2. `node server.js`
3. Open `http://localhost:3000` in your browser.
4. Enter a room code (same as your friends) to play together.

WASD to move, mouse to shoot.
