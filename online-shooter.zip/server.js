
const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

const PORT = process.env.PORT || 3000;

app.use(express.static('public'));

let rooms = {};

io.on('connection', (socket) => {
  console.log(`🟢 New connection: ${socket.id}`);

  socket.on('joinRoom', (roomCode) => {
    socket.join(roomCode);
    console.log(`📦 ${socket.id} joined room ${roomCode}`);

    if (!rooms[roomCode]) rooms[roomCode] = [];
    rooms[roomCode].push(socket.id);

    socket.emit('init', { id: socket.id, players: rooms[roomCode] });

    socket.to(roomCode).emit('playerJoined', socket.id);

    socket.on('update', (data) => {
      socket.to(roomCode).emit('update', { id: socket.id, data });
    });

    socket.on('shoot', (bulletData) => {
      socket.to(roomCode).emit('shoot', { id: socket.id, bulletData });
    });

    socket.on('disconnect', () => {
      console.log(`🔴 ${socket.id} disconnected`);
      socket.to(roomCode).emit('playerLeft', socket.id);
      if (rooms[roomCode]) {
        rooms[roomCode] = rooms[roomCode].filter(id => id !== socket.id);
        if (rooms[roomCode].length === 0) delete rooms[roomCode];
      }
    });
  });
});

http.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
