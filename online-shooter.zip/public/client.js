
const socket = io();
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let playerId;
let players = {};
let bullets = [];

let roomCode = prompt("Enter room code:");
socket.emit('joinRoom', roomCode);

socket.on('init', (data) => {
  playerId = data.id;
  data.players.forEach(id => {
    if (id !== playerId) players[id] = { x: 400, y: 300 };
  });
});

socket.on('playerJoined', (id) => {
  players[id] = { x: 400, y: 300 };
});

socket.on('playerLeft', (id) => {
  delete players[id];
});

socket.on('update', ({ id, data }) => {
  if (players[id]) players[id] = data;
});

socket.on('shoot', ({ id, bulletData }) => {
  bullets.push(bulletData);
});

const self = { x: 400, y: 300, speed: 3 };
let keys = {};

document.addEventListener('keydown', e => keys[e.key] = true);
document.addEventListener('keyup', e => keys[e.key] = false);

canvas.addEventListener('click', e => {
  const rect = canvas.getBoundingClientRect();
  const targetX = e.clientX - rect.left;
  const targetY = e.clientY - rect.top;
  const angle = Math.atan2(targetY - self.y, targetX - self.x);
  const bullet = { x: self.x, y: self.y, dx: Math.cos(angle) * 5, dy: Math.sin(angle) * 5 };
  bullets.push(bullet);
  socket.emit('shoot', bullet);
});

function update() {
  if (keys['w']) self.y -= self.speed;
  if (keys['s']) self.y += self.speed;
  if (keys['a']) self.x -= self.speed;
  if (keys['d']) self.x += self.speed;

  socket.emit('update', self);
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  // self
  ctx.fillStyle = 'lime';
  ctx.fillRect(self.x - 10, self.y - 10, 20, 20);
  // others
  ctx.fillStyle = 'red';
  for (let id in players) {
    const p = players[id];
    ctx.fillRect(p.x - 10, p.y - 10, 20, 20);
  }
  // bullets
  ctx.fillStyle = 'white';
  bullets.forEach(b => {
    b.x += b.dx;
    b.y += b.dy;
    ctx.fillRect(b.x, b.y, 5, 5);
  });
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

gameLoop();
